const express = require("express");
const crypto = require("crypto");
const Database = require("better-sqlite3");
const path = require("path");

const app = express();
app.use(express.json({ limit: "100kb" }));
app.use(express.static(path.join(__dirname, "public")));

const PORT = process.env.PORT || 3000;
const BOT_TOKEN = process.env.BOT_TOKEN || "";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "";
const DEV_MODE = process.env.DEV_MODE === "true";
const DB_PATH = process.env.DB_PATH || path.join(__dirname, "data", "minology.sqlite");
require("fs").mkdirSync(path.dirname(DB_PATH), { recursive: true });
const db = new Database(DB_PATH);
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id TEXT PRIMARY KEY, username TEXT, balance REAL NOT NULL DEFAULT 0,
 total_mined REAL NOT NULL DEFAULT 0, power REAL NOT NULL DEFAULT 1,
 last_claim INTEGER NOT NULL, created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS tasks (
 id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, url TEXT NOT NULL,
 reward REAL NOT NULL, channel TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS task_done (
 user_id TEXT NOT NULL, task_id INTEGER NOT NULL, created_at INTEGER NOT NULL,
 PRIMARY KEY(user_id, task_id)
);
CREATE TABLE IF NOT EXISTS withdrawals (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT NOT NULL, amount REAL NOT NULL,
 wallet TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending', created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
`);
const defaults = {
 token_name: "MINO", min_withdrawal: "1000", min_hold_days: "7",
 hold_amount: "1000", mining_per_hour_per_power: "1",
 upgrades: JSON.stringify([{level:2,power:3,gram:5},{level:3,power:8,gram:15},{level:4,power:20,gram:35},{level:5,power:50,gram:75}])
};
for (const [k,v] of Object.entries(defaults)) db.prepare("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)").run(k,v);

const getSetting = k => db.prepare("SELECT value FROM settings WHERE key=?").get(k)?.value;
const setSetting = (k,v) => db.prepare("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").run(k,String(v));
const now = () => Math.floor(Date.now()/1000);

function verifyTelegram(initData) {
  if (DEV_MODE && !initData) return { id: "demo-user", username: "demo_user" };
  if (!BOT_TOKEN || !initData) throw new Error("Telegram authentication required");
  const p = new URLSearchParams(initData);
  const hash = p.get("hash"); p.delete("hash");
  if (!hash) throw new Error("Invalid Telegram data");
  const check = [...p.entries()].sort(([a],[b])=>a.localeCompare(b)).map(([k,v])=>`${k}=${v}`).join("\n");
  const secret = crypto.createHmac("sha256", "WebAppData").update(BOT_TOKEN).digest();
  const calc = crypto.createHmac("sha256", secret).update(check).digest("hex");
  if (!crypto.timingSafeEqual(Buffer.from(calc), Buffer.from(hash))) throw new Error("Telegram signature mismatch");
  const authDate = Number(p.get("auth_date") || 0);
  if (!authDate || now()-authDate > 86400) throw new Error("Telegram session expired");
  const user = JSON.parse(p.get("user") || "{}");
  if (!user.id) throw new Error("Telegram user missing");
  return { id: String(user.id), username: user.username || user.first_name || "player" };
}
function auth(req,res,next) {
  try {
    const raw = req.headers["x-telegram-init-data"] || "";
    req.user = verifyTelegram(raw);
    const t = now();
    db.prepare(`INSERT OR IGNORE INTO users(id,username,last_claim,created_at) VALUES(?,?,?,?)`)
      .run(req.user.id, req.user.username, t, t);
    db.prepare("UPDATE users SET username=? WHERE id=?").run(req.user.username,req.user.id);
    next();
  } catch(e) { res.status(401).json({error:e.message}); }
}
function accrue(user) {
  const t=now(), elapsed=Math.max(0,Math.min(t-user.last_claim, 86400*7));
  const rate=Number(getSetting("mining_per_hour_per_power"))/3600;
  const earned=elapsed*user.power*rate;
  db.prepare("UPDATE users SET balance=balance+?, total_mined=total_mined+?, last_claim=? WHERE id=?")
    .run(earned,earned,t,user.id);
}
function currentUser(id) { const u=db.prepare("SELECT * FROM users WHERE id=?").get(id); accrue(u); return db.prepare("SELECT * FROM users WHERE id=?").get(id); }

app.get("/api/config",(req,res)=>res.json({
 tokenName:getSetting("token_name"), minWithdrawal:Number(getSetting("min_withdrawal")),
 minHoldDays:Number(getSetting("min_hold_days")), holdAmount:Number(getSetting("hold_amount")),
 rate:Number(getSetting("mining_per_hour_per_power"))
}));
app.get("/api/me",auth,(req,res)=>{
 const u=currentUser(req.user.id);
 res.json({id:u.id,username:u.username,balance:u.balance,totalMined:u.total_mined,power:u.power,lastClaim:u.last_claim});
});
app.get("/api/tasks",auth,(req,res)=>{
 const rows=db.prepare(`SELECT t.*, CASE WHEN d.user_id IS NULL THEN 0 ELSE 1 END done
 FROM tasks t LEFT JOIN task_done d ON d.task_id=t.id AND d.user_id=? WHERE t.active=1`).all(req.user.id);
 res.json(rows);
});
app.post("/api/tasks/:id/claim",auth,(req,res)=>{
 const id=Number(req.params.id), task=db.prepare("SELECT * FROM tasks WHERE id=? AND active=1").get(id);
 if(!task) return res.status(404).json({error:"Task not found"});
 if(db.prepare("SELECT 1 FROM task_done WHERE user_id=? AND task_id=?").get(req.user.id,id)) return res.status(409).json({error:"Already claimed"});
 // Membership must be verified by a bot that is an administrator in the target channel.
 // This MVP deliberately does not reward a click alone.
 return res.status(501).json({error:"Membership verification is not configured yet. Add the bot as channel admin before enabling task rewards."});
});
app.get("/api/upgrades",auth,(req,res)=>res.json(JSON.parse(getSetting("upgrades"))));
app.post("/api/withdraw",auth,(req,res)=>{
 const u=currentUser(req.user.id), amount=Number(req.body.amount), wallet=String(req.body.wallet||"").trim();
 if(!Number.isFinite(amount)||amount<Number(getSetting("min_withdrawal"))) return res.status(400).json({error:"Below minimum withdrawal"});
 if(!wallet || wallet.length<20 || wallet.length>150) return res.status(400).json({error:"Enter a valid TON wallet address"});
 if(u.balance<amount) return res.status(400).json({error:"Insufficient balance"});
 const hold=Number(getSetting("hold_amount"));
 if(u.balance<hold) return res.status(400).json({error:`Minimum hold balance is ${hold} ${getSetting("token_name")}`});
 db.prepare("UPDATE users SET balance=balance-? WHERE id=?").run(amount,u.id);
 const info=db.prepare("INSERT INTO withdrawals(user_id,amount,wallet,created_at) VALUES(?,?,?,?)").run(u.id,amount,wallet,now());
 res.json({ok:true,id:info.lastInsertRowid,status:"pending"});
});
app.get("/api/history",auth,(req,res)=>res.json(db.prepare("SELECT id,amount,wallet,status,created_at FROM withdrawals WHERE user_id=? ORDER BY id DESC LIMIT 30").all(req.user.id)));

function admin(req,res,next) {
 const supplied=req.headers["x-admin-password"]||"";
 if(!ADMIN_PASSWORD || supplied!==ADMIN_PASSWORD) return res.status(403).json({error:"Admin access denied"});
 next();
}
app.get("/admin", (req,res)=>res.sendFile(path.join(__dirname,"public","admin.html")));
app.get("/api/admin/overview",admin,(req,res)=>{
 res.json({users:db.prepare("SELECT COUNT(*) n FROM users").get().n,
 pending:db.prepare("SELECT COUNT(*) n FROM withdrawals WHERE status='pending'").get().n,
 withdrawals:db.prepare("SELECT * FROM withdrawals ORDER BY id DESC LIMIT 100").all(),
 tasks:db.prepare("SELECT * FROM tasks ORDER BY id DESC").all()});
});
app.post("/api/admin/tasks",admin,(req,res)=>{
 const {title,url,reward,channel}=req.body;
 if(!title||!url||!channel||!Number.isFinite(Number(reward))||Number(reward)<=0) return res.status(400).json({error:"Invalid task"});
 const r=db.prepare("INSERT INTO tasks(title,url,reward,channel) VALUES(?,?,?,?)").run(title,url,Number(reward),channel);
 res.json({ok:true,id:r.lastInsertRowid});
});
app.post("/api/admin/withdrawals/:id",admin,(req,res)=>{
 const status=req.body.status;
 if(!["approved","rejected"].includes(status)) return res.status(400).json({error:"Invalid status"});
 const w=db.prepare("SELECT * FROM withdrawals WHERE id=? AND status='pending'").get(Number(req.params.id));
 if(!w) return res.status(404).json({error:"Request not found"});
 const tx=db.transaction(()=>{
   db.prepare("UPDATE withdrawals SET status=? WHERE id=?").run(status,w.id);
   if(status==="rejected") db.prepare("UPDATE users SET balance=balance+? WHERE id=?").run(w.amount,w.user_id);
 });
 tx(); res.json({ok:true});
});
app.post("/api/admin/settings",admin,(req,res)=>{
 const allowed=["token_name","min_withdrawal","min_hold_days","hold_amount","mining_per_hour_per_power","upgrades"];
 for(const k of allowed) if(req.body[k]!==undefined) setSetting(k,typeof req.body[k]==="object"?JSON.stringify(req.body[k]):req.body[k]);
 res.json({ok:true});
});
app.get("/api/admin/settings",admin,(req,res)=>{
 const out={}; for(const k of Object.keys(defaults)) out[k]=getSetting(k); res.json(out);
});
app.listen(PORT,()=>console.log(`MINOLOGY running on ${PORT}`));
